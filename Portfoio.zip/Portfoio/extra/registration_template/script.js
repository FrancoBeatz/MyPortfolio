// Toggle password visibility
document.querySelectorAll('.toggle-pass').forEach(btn => {
    btn.addEventListener('click', function () {
        const input = this.closest('.password-field').querySelector('input');
        if (input.type === 'password') {
            input.type = 'text';
            this.innerHTML = '<i class="bi bi-eye-slash"></i>';
        } else {
            input.type = 'password';
            this.innerHTML = '<i class="bi bi-eye"></i>';
        }
    });
});

// --- Simple starfield background ---
const canvas = document.getElementById('bgCanvas');
const ctx = canvas.getContext('2d');
let stars = [];
let w, h;

function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);

function initStars() {
    stars = [];
    for (let i = 0; i < 200; i++) {
        stars.push({
            x: Math.random() * w,
            y: Math.random() * h,
            z: Math.random() * w
        });
    }
}
initStars();

function animate() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#00e5ff';

    stars.forEach(star => {
        star.z -= 2;
        if (star.z <= 0) star.z = w;

        const k = 128 / star.z;
        const sx = star.x * k + w / 2;
        const sy = star.y * k + h / 2;

        if (sx < 0 || sx >= w || sy < 0 || sy >= h) return;

        const size = (1 - star.z / w) * 2;
        ctx.fillRect(sx, sy, size, size);
    });

    requestAnimationFrame(animate);
}
animate();

// 3D card tilt effect
const glassCard = document.querySelector('.glass');
if (glassCard) {
    glassCard.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * 8;
        const rotateY = ((x - centerX) / centerX) * -8;
        this.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.03)`;
    });
    glassCard.addEventListener('mouseleave', function () {
        this.style.transform = 'perspective(800px) translateZ(20px) scale(1.03)';
    });
}

