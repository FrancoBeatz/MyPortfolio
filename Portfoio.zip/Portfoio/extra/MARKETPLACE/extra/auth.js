document.addEventListener("DOMContentLoaded", () => {
  // Signup form validation
  document.getElementById("signupForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("signupName").value.trim();
    const email = document.getElementById("signupEmail").value.trim();
    const password = document.getElementById("signupPassword").value;

    if (password.length < 6) {
      alert("Password must be at least 6 characters long.");
      return;
    }
    alert(`✅ Account created for ${name} (${email})`);
    // TODO: connect to backend later
  });

  // Login form validation
  document.getElementById("loginForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    if (!email || !password) {
      alert("Please fill in both fields.");
      return;
    }
    alert(`✅ Logged in as ${email}`);
    // TODO: connect to backend later
  });
});
