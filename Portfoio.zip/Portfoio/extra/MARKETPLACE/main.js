/* ============================================================
   T-Bang MarketPlace | Shopping Site JavaScript
   Author: T-Bang Code
   Purpose: Add interactivity, cart functionality, form validation,
            product filtering, and dynamic UI effects.
   ============================================================ */

/* -------------------------------
   1. Bootstrap Carousel (Sliders)
--------------------------------- */
// Initialize all Bootstrap carousels on page load
document.addEventListener("DOMContentLoaded", () => {
  const carousels = document.querySelectorAll(".carousel");
  carousels.forEach((carousel) => {
    new bootstrap.Carousel(carousel, {
      interval: 4000, // auto-slide every 4s
      ride: "carousel",
      pause: "hover",
      wrap: true,
    });
  });
});

/* -------------------------------
   2. Shopping Cart Functionality
--------------------------------- */
// Store cart items in localStorage for persistence
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Add to cart
function addToCart(productId, productName, productPrice, productImage) {
  const existing = cart.find((item) => item.id === productId);

  if (existing) {
    existing.quantity += 1; // increment quantity if already in cart
  } else {
    cart.push({
      id: productId,
      name: productName,
      price: parseFloat(productPrice),
      image: productImage,
      quantity: 1,
    });
  }

  updateCartUI();
  saveCart();
}

// Remove from cart
function removeFromCart(productId) {
  cart = cart.filter((item) => item.id !== productId);
  updateCartUI();
  saveCart();
}

// Update item quantity
function updateQuantity(productId, quantity) {
  const item = cart.find((item) => item.id === productId);
  if (item) {
    item.quantity = quantity > 0 ? quantity : 1;
  }
  updateCartUI();
  saveCart();
}

// Save cart to localStorage
function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cart));
}

// Update cart UI (example modal/cart section)
function updateCartUI() {
  const cartContainer = document.querySelector("#cart-items");
  const cartTotal = document.querySelector("#cart-total");

  if (!cartContainer || !cartTotal) return;

  cartContainer.innerHTML = "";

  let total = 0;
  cart.forEach((item) => {
    total += item.price * item.quantity;

    const row = document.createElement("div");
    row.classList.add("cart-item", "d-flex", "justify-content-between", "align-items-center", "mb-2");

    row.innerHTML = `
      <div class="d-flex align-items-center">
        <img src="${item.image}" alt="${item.name}" class="me-2" style="width: 50px; height: 50px; object-fit: cover;">
        <span>${item.name} (x${item.quantity})</span>
      </div>
      <div>
        <strong>$${(item.price * item.quantity).toFixed(2)}</strong>
        <button class="btn btn-sm btn-danger ms-2" onclick="removeFromCart('${item.id}')">X</button>
      </div>
    `;
    cartContainer.appendChild(row);
  });

  cartTotal.textContent = `$${total.toFixed(2)}`;
}

// Initialize cart UI on page load
document.addEventListener("DOMContentLoaded", updateCartUI);

/* -------------------------------
   3. Checkout Form Validation
--------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  const checkoutForm = document.querySelector("#checkout-form");

  if (checkoutForm) {
    checkoutForm.addEventListener("submit", (e) => {
      e.preventDefault();

      // Basic validation (can be expanded with regex)
      const name = checkoutForm.querySelector("#name").value.trim();
      const email = checkoutForm.querySelector("#email").value.trim();
      const address = checkoutForm.querySelector("#address").value.trim();
      const payment = checkoutForm.querySelector("#payment").value.trim();

      if (!name || !email || !address || !payment) {
        alert("Please fill in all required fields.");
        return;
      }

      // Email validation
      const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        return;
      }

      alert("Checkout successful! Thank you for your purchase.");
      cart = [];
      saveCart();
      updateCartUI();
      checkoutForm.reset();
    });
  }
});

/* -------------------------------
   4. Product Search & Filtering
--------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  const searchInput = document.querySelector("#search-input");
  const productCards = document.querySelectorAll(".product-card");

  if (searchInput) {
    searchInput.addEventListener("keyup", () => {
      const filter = searchInput.value.toLowerCase();

      productCards.forEach((card) => {
        const title = card.querySelector(".card-title").textContent.toLowerCase();
        const match = title.includes(filter);
        card.style.display = match ? "block" : "none";
      });
    });
  }
});

/* -------------------------------
   5. Interactive Card Hover Effects
--------------------------------- */
// Adds a 3D tilt effect on hover for product cards
document.querySelectorAll(".product-card").forEach((card) => {
  card.addEventListener("mousemove", (e) => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const rotateY = ((x / rect.width) - 0.5) * 10; // tilt left/right
    const rotateX = ((y / rect.height) - 0.5) * -10; // tilt up/down

    card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "rotateX(0) rotateY(0)";
  });
});

/* -------------------------------
   End of Custom JavaScript
--------------------------------- */
