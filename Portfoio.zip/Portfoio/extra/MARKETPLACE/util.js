(function ($) {
  "use strict";

  /**
   * Generate a nav list for mobile panel navigation
   * Creates simplified link-only nav for slide-in panel
   */
  $.fn.navList = function () {
    let $this = $(this),
      $a = $this.find("a"),
      links = [];

    $a.each(function () {
      let $link = $(this),
        indent = Math.max(0, $link.parents("li").length - 1),
        href = $link.attr("href"),
        target = $link.attr("target");

      links.push(
        `<a class="link depth-${indent}" ${
          target ? `target="${target}"` : ""
        } ${href ? `href="${href}"` : ""}>
          <span class="indent-${indent}"></span>
          ${$link.text()}
        </a>`
      );
    });

    return links.join("");
  };

  /**
   * Turn an element into a slide-in panel (used for nav or cart)
   * Configurable for side, auto-hide, swipe, etc.
   */
  $.fn.panel = function (userConfig) {
    if (!this.length) return $(this);

    // Support multiple elements
    if (this.length > 1) {
      this.each(function () {
        $(this).panel(userConfig);
      });
      return $(this);
    }

    let $this = $(this),
      $body = $("body"),
      $window = $(window),
      id = $this.attr("id"),
      config = $.extend(
        {
          delay: 300, // animation delay
          hideOnClick: true, // hide when clicking links inside
          hideOnEscape: true, // hide on ESC key
          hideOnSwipe: true, // mobile swipe support
          resetScroll: true,
          resetForms: true,
          side: "right", // default slide-in from right (good for cart)
          target: $body,
          visibleClass: "panel-visible",
        },
        userConfig
      );

    // Expand target if needed
    if (typeof config.target !== "jQuery") config.target = $(config.target);

    /**
     * Hide function
     */
    $this._hide = function (event) {
      if (!config.target.hasClass(config.visibleClass)) return;

      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }

      config.target.removeClass(config.visibleClass);

      setTimeout(() => {
        if (config.resetScroll) $this.scrollTop(0);
        if (config.resetForms)
          $this.find("form").each(function () {
            this.reset();
          });
      }, config.delay);
    };

    // Touch fixes
    $this.css({
      "-ms-overflow-style": "-ms-autohiding-scrollbar",
      "-webkit-overflow-scrolling": "touch",
    });

    // Hide on link click
    if (config.hideOnClick) {
      $this.find("a").on("click", function (event) {
        let $a = $(this),
          href = $a.attr("href"),
          target = $a.attr("target");

        if (!href || href === "#" || href === `#${id}`) return;

        event.preventDefault();
        event.stopPropagation();

        $this._hide();

        setTimeout(() => {
          if (target === "_blank") window.open(href);
          else window.location.href = href;
        }, config.delay + 10);
      });
    }

    // Hide on outside click
    $body.on("click touchend", (event) => {
      $this._hide(event);
    });

    // Toggle
    $body.on("click", `a[href="#${id}"]`, function (event) {
      event.preventDefault();
      event.stopPropagation();
      config.target.toggleClass(config.visibleClass);
    });

    // Hide on ESC
    if (config.hideOnEscape) {
      $window.on("keydown", (event) => {
        if (event.key === "Escape") $this._hide(event);
      });
    }

    return $this;
  };

  /**
   * Prioritize elements by moving them to the top on condition
   * Example: Move search/cart icons to top in mobile
   */
  $.prioritize = function ($elements, condition) {
    let key = "__prioritize";

    if (typeof $elements !== "jQuery") $elements = $($elements);

    $elements.each(function () {
      let $e = $(this),
        $parent = $e.parent();

      if (!$parent.length) return;

      // Not moved yet
      if (!$e.data(key)) {
        if (!condition) return;

        let $placeholder = $e.prev();
        if (!$placeholder.length) return;

        $e.prependTo($parent);
        $e.data(key, $placeholder);
      } else {
        if (condition) return;

        let $placeholder = $e.data(key);
        $e.insertAfter($placeholder);
        $e.removeData(key);
      }
    });
  };
})(jQuery);
